# Exercice flexbox : Bonus 

## Vous devez disposer les pièces du jeu d'échec comme sur l'image fournie en utilisant flex box
